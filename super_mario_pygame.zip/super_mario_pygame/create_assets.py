import pygame
import os

pygame.init()

screen = pygame.display.set_mode((100, 100))
pygame.display.set_caption("Creating Assets")

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
BROWN = (139, 69, 19)
MAGENTA = (255, 0, 255)

assets_dir = "assets"
if not os.path.exists(assets_dir):
    os.makedirs(assets_dir)

player_surface = pygame.Surface((30, 50), pygame.SRCALPHA)
pygame.draw.rect(player_surface, RED, (0, 0, 30, 50))
pygame.draw.circle(player_surface, (0, 0, 0), (10, 15), 5)
pygame.draw.circle(player_surface, (0, 0, 0), (20, 15), 5)
pygame.draw.arc(player_surface, (0, 0, 0), (8, 20, 14, 10), 0, 3.14, 2)
pygame.image.save(player_surface, os.path.join(assets_dir, "player.png"))

platform_surface = pygame.Surface((100, 20), pygame.SRCALPHA)
pygame.draw.rect(platform_surface, GREEN, (0, 0, 100, 20))
pygame.draw.line(platform_surface, (0, 100, 0), (0, 0), (100, 0), 2)
pygame.image.save(platform_surface, os.path.join(assets_dir, "platform.png"))

coin_surface = pygame.Surface((20, 20), pygame.SRCALPHA)
pygame.draw.circle(coin_surface, YELLOW, (10, 10), 10)
pygame.draw.circle(coin_surface, (200, 200, 0), (10, 10), 7)
pygame.image.save(coin_surface, os.path.join(assets_dir, "coin.png"))

enemy_surface = pygame.Surface((30, 30), pygame.SRCALPHA)
pygame.draw.rect(enemy_surface, BLUE, (0, 0, 30, 30))
pygame.draw.circle(enemy_surface, (0, 0, 150), (10, 10), 4)
pygame.draw.circle(enemy_surface, (0, 0, 150), (20, 10), 4)
pygame.draw.arc(enemy_surface, (0, 0, 100), (8, 15, 14, 10), 3.14, 0, 2)
pygame.image.save(enemy_surface, os.path.join(assets_dir, "enemy.png"))

goal_surface = pygame.Surface((30, 60), pygame.SRCALPHA)
pygame.draw.rect(goal_surface, MAGENTA, (0, 0, 30, 60))
pygame.draw.polygon(goal_surface, (200, 0, 200), [(15, 0), (30, 20), (0, 20)])
pygame.image.save(goal_surface, os.path.join(assets_dir, "goal.png"))

background_surface = pygame.Surface((800, 600))
background_surface.fill((135, 206, 235))
pygame.draw.circle(background_surface, WHITE, (100, 100), 30)
pygame.draw.circle(background_surface, WHITE, (130, 100), 35)
pygame.draw.circle(background_surface, WHITE, (160, 100), 30)
pygame.draw.circle(background_surface, WHITE, (400, 80), 30)
pygame.draw.circle(background_surface, WHITE, (430, 80), 35)
pygame.draw.circle(background_surface, WHITE, (460, 80), 30)
pygame.image.save(background_surface, os.path.join(assets_dir, "background.png"))

print("Assets created successfully!")

pygame.quit()