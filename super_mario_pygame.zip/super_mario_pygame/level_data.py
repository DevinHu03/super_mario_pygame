# Level data for Super Mario-like game

# Level 1 - Beginner Level (Grassland)
LEVEL_1 = {
    "background": "background_level1.png",
    "platform_type": "platform_grass.png",
    "enemy_type": "enemy_level1.png",
    "platforms": [
        [0, 560, 800, 40],  # Ground
        [200, 450, 100, 20],
        [400, 350, 100, 20],
        [600, 250, 100, 20],
        [300, 500, 100, 20],
    ],
    "coins": [
        [250, 400],
        [450, 300],
        [650, 200],
        [350, 450],
    ],
    "enemies": [
        [300, 530],
        [500, 530],
    ],
    "goal": [750, 500],
    "player_start": [50, 500]
}

# Level 2 - Cave Level (Intermediate)
LEVEL_2 = {
    "background": "background_level2.png",
    "platform_type": "platform_stone.png",
    "enemy_type": "enemy_level2.png",
    "platforms": [
        [0, 560, 800, 40],  # Ground
        [100, 450, 100, 20],
        [300, 350, 100, 20],
        [500, 250, 100, 20],
        [200, 500, 100, 20],
        [400, 400, 100, 20],
        [600, 300, 100, 20],
    ],
    "coins": [
        [150, 400],
        [350, 300],
        [550, 200],
        [250, 450],
        [450, 350],
        [650, 250],
    ],
    "enemies": [
        [200, 530],
        [400, 530],
        [600, 530],
    ],
    "goal": [750, 500],
    "player_start": [50, 500]
}

# Level 3 - Ice Level (Advanced)
LEVEL_3 = {
    "background": "background_level3.png",
    "platform_type": "platform_ice.png",
    "enemy_type": "enemy_level3.png",
    "platforms": [
        [0, 560, 800, 40],  # Ground
        [100, 450, 80, 20],
        [250, 350, 80, 20],
        [400, 250, 80, 20],
        [550, 150, 80, 20],
        [200, 500, 80, 20],
        [350, 400, 80, 20],
        [500, 300, 80, 20],
        [650, 200, 80, 20],
    ],
    "coins": [
        [140, 400],
        [290, 300],
        [440, 200],
        [590, 100],
        [240, 450],
        [390, 350],
        [540, 250],
        [690, 150],
    ],
    "enemies": [
        [150, 530],
        [300, 530],
        [450, 530],
        [600, 530],
    ],
    "goal": [750, 500],
    "player_start": [50, 500]
}

# Level 4 - Lava Level (Expert)
LEVEL_4 = {
    "background": "background_level4.png",
    "platform_type": "platform_lava.png",
    "enemy_type": "enemy_level4.png",
    "platforms": [
        [0, 560, 800, 40],  # Ground
        [50, 450, 70, 20],
        [170, 350, 70, 20],
        [290, 250, 70, 20],
        [410, 150, 70, 20],
        [530, 250, 70, 20],
        [650, 350, 70, 20],
        [150, 500, 70, 20],
        [270, 400, 70, 20],
        [390, 300, 70, 20],
        [510, 400, 70, 20],
        [630, 500, 70, 20],
    ],
    "coins": [
        [85, 400],
        [205, 300],
        [325, 200],
        [445, 100],
        [565, 200],
        [685, 300],
        [205, 450],
        [325, 350],
        [445, 250],
        [565, 350],
        [685, 450],
    ],
    "enemies": [
        [100, 530],
        [220, 530],
        [340, 530],
        [460, 530],
        [580, 530],
        [700, 530],
    ],
    "goal": [750, 500],
    "player_start": [50, 500]
}

# List of all levels
LEVELS = [LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4]