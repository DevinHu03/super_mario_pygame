import pygame
import sys
import os

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 100, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BROWN = (139, 69, 19)
YELLOW = (255, 255, 0)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Super Mario-like Game")
clock = pygame.time.Clock()

assets_dir = "assets"
player_img = pygame.image.load(os.path.join(assets_dir, "player.png")).convert_alpha()
platform_img = pygame.image.load(os.path.join(assets_dir, "platform.png")).convert_alpha()
coin_img = pygame.image.load(os.path.join(assets_dir, "coin.png")).convert_alpha()
enemy_img = pygame.image.load(os.path.join(assets_dir, "enemy.png")).convert_alpha()
goal_img = pygame.image.load(os.path.join(assets_dir, "goal.png")).convert_alpha()
background_img = pygame.image.load(os.path.join(assets_dir, "background.png")).convert()

platform_img = pygame.transform.scale(platform_img, (100, 20))
background_img = pygame.transform.scale(background_img, (SCREEN_WIDTH, SCREEN_HEIGHT))

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = player_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 0
        self.change_y = 0
        self.jumping = False
        self.on_ground = False
        
    def update(self):
        if not self.on_ground:
            self.change_y += 0.5
        self.rect.x += self.change_x
        block_hit_list = pygame.sprite.spritecollide(self, platforms, False)
        for block in block_hit_list:
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                self.rect.left = block.rect.right
        self.rect.y += self.change_y
        self.on_ground = False
        block_hit_list = pygame.sprite.spritecollide(self, platforms, False)
        for block in block_hit_list:
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
                self.on_ground = True
                self.jumping = False
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom
            self.change_y = 0
            
    def jump(self):
        if self.on_ground:
            self.change_y = -12
            self.jumping = True
            self.on_ground = False
            
    def move_left(self):
        self.change_x = -6
        
    def move_right(self):
        self.change_x = 6
        
    def stop(self):
        self.change_x = 0

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.transform.scale(platform_img, (width, height))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = coin_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = enemy_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 2
        self.direction = 1
        
    def update(self):
        self.rect.x += self.change_x * self.direction
        if len(pygame.sprite.spritecollide(self, platforms, False)) > 0:
            self.direction *= -1
            self.rect.x += self.change_x * self.direction

class Goal(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = goal_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

all_sprites = pygame.sprite.Group()
platforms = pygame.sprite.Group()
coins = pygame.sprite.Group()
enemies = pygame.sprite.Group()

player = Player(50, 300)
all_sprites.add(player)

platform_list = [
    [0, SCREEN_HEIGHT - 40, SCREEN_WIDTH, 40],
    [200, 400, 100, 20],
    [400, 300, 100, 20],
    [600, 200, 100, 20],
    [300, 500, 100, 20],
]

for platform in platform_list:
    p = Platform(platform[0], platform[1], platform[2], platform[3])
    platforms.add(p)
    all_sprites.add(p)

coin_positions = [
    [250, 350],
    [450, 250],
    [650, 150],
    [350, 450],
]

for pos in coin_positions:
    coin = Coin(pos[0], pos[1])
    coins.add(coin)
    all_sprites.add(coin)

enemy_positions = [
    [300, SCREEN_HEIGHT - 70],
    [500, SCREEN_HEIGHT - 70],
]

for pos in enemy_positions:
    enemy = Enemy(pos[0], pos[1])
    enemies.add(enemy)
    all_sprites.add(enemy)

goal = Goal(SCREEN_WIDTH - 50, SCREEN_HEIGHT - 100)
all_sprites.add(goal)

score = 0
font = pygame.font.Font(None, 36)
pygame.quit()
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.move_left()
            elif event.key == pygame.K_RIGHT:
                player.move_right()
            elif event.key == pygame.K_SPACE:
                player.jump()
            elif event.key == pygame.K_r:
                player.rect.x = 50
                player.rect.y = 300
                player.change_x = 0
                player.change_y = 0
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT and player.change_x < 0:
                player.stop()
            elif event.key == pygame.K_RIGHT and player.change_x > 0:
                player.stop()
    all_sprites.update()
    coin_hit_list = pygame.sprite.spritecollide(player, coins, True)
    for coin in coin_hit_list:
        score += 10
    enemy_hit_list = pygame.sprite.spritecollide(player, enemies, False)
    if enemy_hit_list:
        player.rect.x = 50
        player.rect.y = 300
        player.change_x = 0
        player.change_y = 0
        score = max(0, score - 5)
    goal_hit = pygame.sprite.collide_rect(player, goal)
    if goal_hit:
        win_text = font.render("You Win! Press R to restart", True, WHITE)
        screen.blit(win_text, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2))
        pygame.display.flip()
        pygame.time.wait(2000)
        player.rect.x = 50
        player.rect.y = 300
        player.change_x = 0
        player.change_y = 0
        score = 0
    screen.blit(background_img, (0, 0))
    all_sprites.draw(screen)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))
    help_text = font.render("Arrow Keys: Move, Space: Jump, R: Reset", True, WHITE)
    screen.blit(help_text, (10, SCREEN_HEIGHT - 30))
    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()