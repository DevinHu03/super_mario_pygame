from setuptools import setup
import py2exe

setup(
    name="Super Mario-like Game",
    version="1.0",
    description="A Super Mario-like game built with Pygame",
    author="Devin",
    options={
        "py2exe": {
            "bundle_files": 1,
            "compressed": True,
            "optimize": 2,
            "includes": ["pygame"],
            "excludes": ["_gtkagg", "_tkagg", "bsddb", "curses", "email", "pywin.debugger",
                        "pywin.debugger.dbgcon", "pywin.dialogs", "tcl",
                        "Tkconstants", "Tkinter"],
            "packages": ["pygame"],
            "dll_excludes": ["w9xpopen.exe"]
        }
    },
    windows=[{"script": "enhanced_game.py"}],
    data_files=[("assets", ["assets/background.png", "assets/coin.png", 
                           "assets/enemy.png", "assets/goal.png", 
                           "assets/platform.png", "assets/player.png"])],
    zipfile=None,
)