import pygame
import os

pygame.init()

screen = pygame.display.set_mode((200, 200))
pygame.display.set_caption("Creating Modern Assets")

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (231, 76, 60)
GREEN = (46, 204, 113)
BLUE = (52, 152, 219)
YELLOW = (241, 196, 15)
BROWN = (150, 120, 70)
PURPLE = (155, 89, 182)
ORANGE = (230, 126, 34)
DARK_GREEN = (39, 174, 96)
DARK_BLUE = (41, 128, 185)
DARK_RED = (192, 57, 43)

assets_dir = "modern_assets"
if not os.path.exists(assets_dir):
    os.makedirs(assets_dir)

player_surface = pygame.Surface((30, 50), pygame.SRCALPHA)
pygame.draw.rect(player_surface, RED, (8, 15, 14, 25))
pygame.draw.circle(player_surface, (255, 200, 180), (15, 12), 8)
pygame.draw.rect(player_surface, RED, (5, 4, 20, 8))
pygame.draw.rect(player_surface, RED, (8, 0, 14, 8))
pygame.draw.circle(player_surface, WHITE, (11, 10), 3)
pygame.draw.circle(player_surface, WHITE, (19, 10), 3)
pygame.draw.circle(player_surface, BLACK, (11, 10), 1.5)
pygame.draw.circle(player_surface, BLACK, (19, 10), 1.5)
pygame.draw.rect(player_surface, (100, 60, 30), (8, 13, 14, 3))
pygame.draw.rect(player_surface, RED, (5, 20, 3, 10))
pygame.draw.rect(player_surface, RED, (22, 20, 3, 10))
pygame.draw.rect(player_surface, BLUE, (10, 40, 4, 10))
pygame.draw.rect(player_surface, BLUE, (16, 40, 4, 10))
pygame.draw.rect(player_surface, (50, 50, 50), (8, 47, 6, 3))
pygame.draw.rect(player_surface, (50, 50, 50), (16, 47, 6, 3))
pygame.image.save(player_surface, os.path.join(assets_dir, "player.png"))

platform_surface = pygame.Surface((100, 20), pygame.SRCALPHA)
pygame.draw.rect(platform_surface, GREEN, (0, 10, 100, 10))
pygame.draw.rect(platform_surface, DARK_GREEN, (0, 0, 100, 10))
for i in range(0, 100, 5):
    pygame.draw.line(platform_surface, DARK_GREEN, (i, 0), (i, 5), 2)
pygame.image.save(platform_surface, os.path.join(assets_dir, "platform_grass.png"))

platform_surface = pygame.Surface((100, 20), pygame.SRCALPHA)
pygame.draw.rect(platform_surface, (127, 140, 141), (0, 0, 100, 20))
pygame.draw.rect(platform_surface, (108, 122, 137), (0, 0, 100, 5))
pygame.draw.rect(platform_surface, (108, 122, 137), (0, 15, 100, 5))
for i in range(0, 100, 10):
    pygame.draw.line(platform_surface, (90, 100, 110), (i, 5), (i, 15), 1)
pygame.image.save(platform_surface, os.path.join(assets_dir, "platform_stone.png"))

platform_surface = pygame.Surface((100, 20), pygame.SRCALPHA)
pygame.draw.rect(platform_surface, (170, 220, 255), (0, 0, 100, 20))
pygame.draw.rect(platform_surface, (200, 230, 255), (0, 0, 100, 3))
pygame.draw.rect(platform_surface, (200, 230, 255), (0, 17, 100, 3))
pygame.draw.line(platform_surface, (220, 240, 255), (0, 10), (100, 10), 1)
pygame.image.save(platform_surface, os.path.join(assets_dir, "platform_ice.png"))

platform_surface = pygame.Surface((100, 20), pygame.SRCALPHA)
pygame.draw.rect(platform_surface, (231, 76, 60), (0, 0, 100, 20))
pygame.draw.rect(platform_surface, (240, 100, 80), (0, 0, 100, 5))
pygame.draw.rect(platform_surface, (240, 100, 80), (0, 15, 100, 5))
for i in range(0, 100, 5):
    pygame.draw.line(platform_surface, (250, 130, 100), (i, 5), (i, 15), 2)
pygame.image.save(platform_surface, os.path.join(assets_dir, "platform_lava.png"))

coin_surface = pygame.Surface((20, 20), pygame.SRCALPHA)
pygame.draw.circle(coin_surface, YELLOW, (10, 10), 10)
pygame.draw.circle(coin_surface, (255, 230, 50), (10, 10), 7)
font = pygame.font.SysFont(None, 20)
dollar = font.render("$", True, (200, 150, 0))
coin_surface.blit(dollar, (6, 2))
pygame.image.save(coin_surface, os.path.join(assets_dir, "coin.png"))

enemy_surface = pygame.Surface((30, 30), pygame.SRCALPHA)
pygame.draw.circle(enemy_surface, BROWN, (15, 18), 12)
pygame.draw.circle(enemy_surface, WHITE, (10, 15), 4)
pygame.draw.circle(enemy_surface, WHITE, (20, 15), 4)
pygame.draw.circle(enemy_surface, BLACK, (10, 15), 2)
pygame.draw.circle(enemy_surface, BLACK, (20, 15), 2)
pygame.draw.arc(enemy_surface, BLACK, (8, 20, 14, 10), 0, 3.14, 2)
pygame.image.save(enemy_surface, os.path.join(assets_dir, "enemy_level1.png"))

enemy_surface = pygame.Surface((30, 40), pygame.SRCALPHA)
pygame.draw.circle(enemy_surface, GREEN, (15, 15), 10)
pygame.draw.ellipse(enemy_surface, (50, 150, 50), (5, 15, 20, 20))
pygame.draw.circle(enemy_surface, WHITE, (10, 13), 3)
pygame.draw.circle(enemy_surface, WHITE, (20, 13), 3)
pygame.draw.circle(enemy_surface, BLACK, (10, 13), 1.5)
pygame.draw.circle(enemy_surface, BLACK, (20, 13), 1.5)
pygame.draw.rect(enemy_surface, (50, 150, 50), (8, 35, 4, 5))
pygame.draw.rect(enemy_surface, (50, 150, 50), (18, 35, 4, 5))
pygame.image.save(enemy_surface, os.path.join(assets_dir, "enemy_level2.png"))

enemy_surface = pygame.Surface((30, 30), pygame.SRCALPHA)
pygame.draw.circle(enemy_surface, (100, 200, 255), (15, 18), 12)
pygame.draw.circle(enemy_surface, (30, 100, 200), (10, 15), 4)
pygame.draw.circle(enemy_surface, (30, 100, 200), (20, 15), 4)
pygame.draw.circle(enemy_surface, WHITE, (10, 15), 2)
pygame.draw.circle(enemy_surface, WHITE, (20, 15), 2)
pygame.draw.arc(enemy_surface, (30, 100, 200), (8, 20, 14, 10), 0, 3.14, 2)
pygame.image.save(enemy_surface, os.path.join(assets_dir, "enemy_level3.png"))

enemy_surface = pygame.Surface((30, 30), pygame.SRCALPHA)
pygame.draw.circle(enemy_surface, ORANGE, (15, 18), 12)
pygame.draw.circle(enemy_surface, RED, (10, 15), 4)
pygame.draw.circle(enemy_surface, RED, (20, 15), 4)
pygame.draw.circle(enemy_surface, YELLOW, (10, 15), 2)
pygame.draw.circle(enemy_surface, YELLOW, (20, 15), 2)
pygame.draw.arc(enemy_surface, RED, (8, 20, 14, 10), 0, 3.14, 2)
pygame.draw.circle(enemy_surface, YELLOW, (5, 5), 3)
pygame.draw.circle(enemy_surface, YELLOW, (25, 5), 3)
pygame.image.save(enemy_surface, os.path.join(assets_dir, "enemy_level4.png"))

goal_surface = pygame.Surface((30, 60), pygame.SRCALPHA)
pygame.draw.rect(goal_surface, (150, 150, 150), (13, 0, 4, 60))
points = [(17, 5), (27, 15), (17, 25)]
pygame.draw.polygon(goal_surface, RED, points)
pygame.draw.polygon(goal_surface, DARK_RED, points, 2)
pygame.image.save(goal_surface, os.path.join(assets_dir, "goal.png"))

background_surface = pygame.Surface((800, 600))
background_surface.fill((135, 206, 235))
pygame.draw.circle(background_surface, (255, 255, 200), (700, 100), 50)
pygame.draw.circle(background_surface, WHITE, (100, 100), 30)
pygame.draw.circle(background_surface, WHITE, (130, 100), 35)
pygame.draw.circle(background_surface, WHITE, (160, 100), 30)
pygame.draw.circle(background_surface, WHITE, (400, 80), 30)
pygame.draw.circle(background_surface, WHITE, (430, 80), 35)
pygame.draw.circle(background_surface, WHITE, (460, 80), 30)
pygame.image.save(background_surface, os.path.join(assets_dir, "background_level1.png"))

background_surface = pygame.Surface((800, 600))
background_surface.fill((50, 50, 50))
for i in range(0, 800, 100):
    points = [(i, 0), (i-10, 30), (i+10, 30)]
    pygame.draw.polygon(background_surface, (70, 70, 70), points)
pygame.draw.circle(background_surface, (80, 80, 80), (200, 500), 50)
pygame.draw.circle(background_surface, (80, 80, 80), (600, 450), 70)
pygame.image.save(background_surface, os.path.join(assets_dir, "background_level2.png"))

background_surface = pygame.Surface((800, 600))
background_surface.fill((200, 230, 255))
pygame.draw.rect(background_surface, WHITE, (0, 500, 800, 100))
points = [(0, 500), (200, 300), (400, 500)]
pygame.draw.polygon(background_surface, (220, 240, 255), points)
points = [(400, 500), (600, 250), (800, 500)]
pygame.draw.polygon(background_surface, (220, 240, 255), points)
for i in range(50):
    x = (i * 37) % 800
    y = (i * 23) % 500
    pygame.draw.circle(background_surface, WHITE, (x, y), 2)
pygame.image.save(background_surface, os.path.join(assets_dir, "background_level3.png"))

background_surface = pygame.Surface((800, 600))
background_surface.fill((50, 0, 0))
pygame.draw.ellipse(background_surface, (231, 76, 60), (100, 500, 200, 100))
pygame.draw.ellipse(background_surface, (231, 76, 60), (500, 450, 250, 150))
for i in range(20):
    x = 150 + (i * 20) % 150
    y = 520 + (i * 15) % 50
    pygame.draw.circle(background_surface, (250, 130, 100), (x, y), 5 + (i % 10))
pygame.draw.circle(background_surface, (80, 60, 60), (300, 400), 50)
pygame.draw.circle(background_surface, (80, 60, 60), (700, 350), 70)
pygame.image.save(background_surface, os.path.join(assets_dir, "background_level4.png"))

print("Modern assets created successfully!")

pygame.quit()