import pygame
import sys
import os
from level_data import LEVELS

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (231, 76, 60)
GREEN = (46, 204, 113)
BLUE = (52, 152, 219)
YELLOW = (241, 196, 15)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Super Mario-like Game")
clock = pygame.time.Clock()

assets_dir = "modern_assets"

player_img = pygame.image.load(os.path.join(assets_dir, "player.png")).convert_alpha()

goal_img = pygame.image.load(os.path.join(assets_dir, "goal.png")).convert_alpha()

coin_img = pygame.image.load(os.path.join(assets_dir, "coin.png")).convert_alpha()

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = player_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 0
        self.change_y = 0
        self.jumping = False
        self.on_ground = False
        
    def update(self):
        if not self.on_ground:
            self.change_y += 0.5
        self.rect.x += self.change_x
        block_hit_list = pygame.sprite.spritecollide(self, platforms, False)
        for block in block_hit_list:
            if self.change_x > 0:
                self.rect.right = block.rect.left
            elif self.change_x < 0:
                self.rect.left = block.rect.right
        self.rect.y += self.change_y
        self.on_ground = False
        block_hit_list = pygame.sprite.spritecollide(self, platforms, False)
        for block in block_hit_list:
            if self.change_y > 0:
                self.rect.bottom = block.rect.top
                self.on_ground = True
                self.jumping = False
            elif self.change_y < 0:
                self.rect.top = block.rect.bottom
            self.change_y = 0
            
    def jump(self):
        if self.on_ground:
            self.change_y = -12
            self.jumping = True
            self.on_ground = False
            
    def move_left(self):
        self.change_x = -6
        
    def move_right(self):
        self.change_x = 6
        
    def stop(self):
        self.change_x = 0

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, image):
        super().__init__()
        self.image = pygame.transform.scale(image, (width, height))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Coin(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = coin_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.change_x = 2
        self.direction = 1
        
    def update(self):
        self.rect.x += self.change_x * self.direction
        
        if len(pygame.sprite.spritecollide(self, platforms, False)) > 0:
            self.direction *= -1
            self.rect.x += self.change_x * self.direction

class Goal(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = goal_img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


all_sprites = pygame.sprite.Group()
platforms = pygame.sprite.Group()
coins = pygame.sprite.Group()
enemies = pygame.sprite.Group()


current_level = 0
score = 0
lives = 3
font = pygame.font.Font(None, 36)
level_font = pygame.font.Font(None, 48)

def load_level(level_num):
    global all_sprites, platforms, coins, enemies, player, goal, background
    
    
    all_sprites.empty()
    platforms.empty()
    coins.empty()
    enemies.empty()
    
    
    level = LEVELS[level_num]
    
    
    background = pygame.image.load(os.path.join(assets_dir, level["background"])).convert()
    background = pygame.transform.scale(background, (SCREEN_WIDTH, SCREEN_HEIGHT))
    
    
    platform_img = pygame.image.load(os.path.join(assets_dir, level["platform_type"])).convert_alpha()
    
    
    enemy_img = pygame.image.load(os.path.join(assets_dir, level["enemy_type"])).convert_alpha()
    
    
    player = Player(level["player_start"][0], level["player_start"][1])
    all_sprites.add(player)
    
    
    for platform in level["platforms"]:
        p = Platform(platform[0], platform[1], platform[2], platform[3], platform_img)
        platforms.add(p)
        all_sprites.add(p)
    
    
    for pos in level["coins"]:
        coin = Coin(pos[0], pos[1])
        coins.add(coin)
        all_sprites.add(coin)
    
    
    for pos in level["enemies"]:
        enemy = Enemy(pos[0], pos[1], enemy_img)
        enemies.add(enemy)
        all_sprites.add(enemy)
    
    
    goal = Goal(level["goal"][0], level["goal"][1])
    all_sprites.add(goal)
    
    return player


player = load_level(current_level)


running = True
while running:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                player.move_left()
            elif event.key == pygame.K_RIGHT:
                player.move_right()
            elif event.key == pygame.K_SPACE:
                player.jump()
            elif event.key == pygame.K_r:
                
                player = load_level(current_level)
        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT and player.change_x < 0:
                player.stop()
            elif event.key == pygame.K_RIGHT and player.change_x > 0:
                player.stop()
    
    
    all_sprites.update()
    
    
    coin_hit_list = pygame.sprite.spritecollide(player, coins, True)
    for coin in coin_hit_list:
        score += 10
    
    
    enemy_hit_list = pygame.sprite.spritecollide(player, enemies, False)
    if enemy_hit_list:
        lives -= 1
        if lives <= 0:
            
            game_over_text = font.render("Game Over! Press R to restart", True, WHITE)
            screen.blit(game_over_text, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2))
            pygame.display.flip()
            pygame.time.wait(2000)
            
            current_level = 0
            score = 0
            lives = 3
            player = load_level(current_level)
        else:
            
            player = load_level(current_level)
    
    
    goal_hit = pygame.sprite.collide_rect(player, goal)
    if goal_hit:
        # Move to next level
        current_level += 1
        if current_level >= len(LEVELS):
            # Game completed
            win_text = font.render("You Completed All Levels! Press R to restart", True, WHITE)
            screen.blit(win_text, (SCREEN_WIDTH // 2 - 200, SCREEN_HEIGHT // 2))
            pygame.display.flip()
            pygame.time.wait(3000)
            # Reset game
            current_level = 0
            score = 0
            lives = 3
            player = load_level(current_level)
        else:
            # Load next level
            level_complete_text = level_font.render(f"Level {current_level} Complete!", True, WHITE)
            screen.blit(level_complete_text, (SCREEN_WIDTH // 2 - 150, SCREEN_HEIGHT // 2))
            pygame.display.flip()
            pygame.time.wait(1500)
            player = load_level(current_level)
    
    # Draw everything
    screen.blit(background, (0, 0))
    
    # Draw sprites
    all_sprites.draw(screen)
    
    # Draw UI
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_text, (10, 10))
    
    lives_text = font.render(f"Lives: {lives}", True, WHITE)
    screen.blit(lives_text, (10, 50))
    
    level_text = font.render(f"Level: {current_level + 1}", True, WHITE)
    screen.blit(level_text, (10, 90))
    
    # Draw controls help
    help_text = font.render("Arrow Keys: Move, Space: Jump, R: Reset", True, WHITE)
    screen.blit(help_text, (10, SCREEN_HEIGHT - 30))
    
    # Update display
    pygame.display.flip()
    
    # Cap the frame rate
    clock.tick(FPS)

# Quit pygame
pygame.quit()
sys.exit()